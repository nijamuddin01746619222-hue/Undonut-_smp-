
import React, { useState, useEffect } from 'react';
import { StudioType } from './types';
import ChatStudio from './components/ChatStudio';
import ImageStudio from './components/ImageStudio';
import VideoStudio from './components/VideoStudio';
import AudioStudio from './components/AudioStudio';
import ExplorerStudio from './components/ExplorerStudio';

const App: React.FC = () => {
  const [activeStudio, setActiveStudio] = useState<StudioType>(StudioType.CHAT);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const navItems = [
    { type: StudioType.CHAT, icon: 'fa-comments', label: 'Chat Hub' },
    { type: StudioType.VISUAL, icon: 'fa-image', label: 'Visual Studio' },
    { type: StudioType.MOTION, icon: 'fa-film', label: 'Motion Studio' },
    { type: StudioType.VOCAL, icon: 'fa-microphone', label: 'Vocal Studio' },
    { type: StudioType.EXPLORER, icon: 'fa-earth-americas', label: 'Explorer' },
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      {/* Sidebar */}
      <aside className={`${isSidebarOpen ? 'w-64' : 'w-20'} bg-white border-r border-gray-200 transition-all duration-300 flex flex-col`}>
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
            <i className="fa-solid fa-sparkles"></i>
          </div>
          {isSidebarOpen && <h1 className="font-bold text-xl tracking-tight">OmniGemini</h1>}
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.type}
              onClick={() => setActiveStudio(item.type)}
              className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
                activeStudio === item.type
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              <i className={`fa-solid ${item.icon} text-lg w-6`}></i>
              {isSidebarOpen && <span className="font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-100">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="w-full flex items-center justify-center p-2 text-gray-400 hover:text-indigo-600 rounded-lg"
          >
            <i className={`fa-solid ${isSidebarOpen ? 'fa-chevron-left' : 'fa-chevron-right'}`}></i>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto relative">
        <div className="max-w-6xl mx-auto p-4 md:p-8 h-full">
          {activeStudio === StudioType.CHAT && <ChatStudio />}
          {activeStudio === StudioType.VISUAL && <ImageStudio />}
          {activeStudio === StudioType.MOTION && <VideoStudio />}
          {activeStudio === StudioType.VOCAL && <AudioStudio />}
          {activeStudio === StudioType.EXPLORER && <ExplorerStudio />}
        </div>
      </main>
    </div>
  );
};

export default App;
