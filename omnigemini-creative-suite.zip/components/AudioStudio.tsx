
import React, { useState, useRef, useEffect } from 'react';
import { generateSpeech } from '../geminiService';
import { GoogleGenAI, Modality } from '@google/genai';
import { encode, decode, decodeAudioData } from '../utils';

const AudioStudio: React.FC = () => {
  const [ttsInput, setTtsInput] = useState('');
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [transcriptions, setTranscriptions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // References for Live API
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef(new Set<AudioBufferSourceNode>());

  const handleTTS = async () => {
    if (!ttsInput.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await generateSpeech(ttsInput);
      const base64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const buffer = await decodeAudioData(decode(base64), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start();
      }
    } catch (err) {
      alert('TTS failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const startLiveSession = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new AudioContext({ sampleRate: 16000 });
      const outputCtx = new AudioContext({ sampleRate: 24000 });
      audioContextRef.current = outputCtx;
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsLiveActive(true);
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const media = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000'
              };
              sessionPromise.then(s => s.sendRealtimeInput({ media }));
            };
            source.connect(processor);
            processor.connect(inputCtx.destination);
          },
          onmessage: async (msg) => {
            if (msg.serverContent?.outputTranscription) {
               setTranscriptions(prev => [...prev, `AI: ${msg.serverContent!.outputTranscription!.text}`]);
            }
            const base64 = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64) {
              const buf = await decodeAudioData(decode(base64), outputCtx, 24000, 1);
              const src = outputCtx.createBufferSource();
              src.buffer = buf;
              src.connect(outputCtx.destination);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              src.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buf.duration;
              sourcesRef.current.add(src);
              src.onended = () => sourcesRef.current.delete(src);
            }
            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onclose: () => setIsLiveActive(false),
          onerror: () => setIsLiveActive(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      alert('Live session failed to start.');
    }
  };

  const stopLiveSession = () => {
    sessionRef.current?.close();
    setIsLiveActive(false);
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-2xl font-bold">Vocal Studio</h2>
        <p className="text-gray-500">Real-time voice conversation & Text-to-Speech generation.</p>
      </header>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Live Conversation */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center space-y-6">
          <h3 className="font-bold text-lg">Conversational Voice API</h3>
          <div className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-500 ${isLiveActive ? 'bg-red-50 ring-8 ring-red-100 scale-110' : 'bg-indigo-50'}`}>
            <i className={`fa-solid fa-microphone text-4xl ${isLiveActive ? 'text-red-600 animate-pulse' : 'text-indigo-600'}`}></i>
          </div>
          <div className="text-center">
             <p className="text-sm font-medium text-gray-700">{isLiveActive ? 'Live and listening...' : 'Start a real-time conversation.'}</p>
             <p className="text-xs text-gray-400 mt-1">Uses Gemini 2.5 Native Audio</p>
          </div>
          <button
            onClick={isLiveActive ? stopLiveSession : startLiveSession}
            className={`px-8 py-3 rounded-xl font-bold transition-all ${isLiveActive ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}
          >
            {isLiveActive ? 'End Session' : 'Start Session'}
          </button>
          
          <div className="w-full h-40 overflow-y-auto bg-gray-50 rounded-xl p-3 text-xs space-y-2">
            {transcriptions.map((t, i) => <div key={i} className="text-gray-600">{t}</div>)}
            {transcriptions.length === 0 && <p className="text-gray-300 text-center mt-12">No transcription yet.</p>}
          </div>
        </div>

        {/* TTS */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col space-y-4">
          <h3 className="font-bold text-lg">Speech Generation</h3>
          <p className="text-xs text-gray-400">Transform text into natural-sounding multi-speaker speech.</p>
          <textarea
            value={ttsInput}
            onChange={(e) => setTtsInput(e.target.value)}
            placeholder="What should I say?"
            className="flex-1 min-h-[150px] p-4 bg-gray-50 rounded-xl border-none outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={handleTTS}
            disabled={isLoading || !ttsInput.trim()}
            className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50"
          >
            {isLoading ? <i className="fa-solid fa-spinner fa-spin mr-2"></i> : null}
            Generate Speech
          </button>
        </div>
      </div>
    </div>
  );
};

export default AudioStudio;
