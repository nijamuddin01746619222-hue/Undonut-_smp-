
import React, { useState, useRef } from 'react';
import { ChatMessage } from '../types';
import { chatWithThinking, chatFast, transcribeAudio } from '../geminiService';
import { fileToBase64 } from '../utils';

const ChatStudio: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useThinking, setUseThinking] = useState(false);
  const [useFast, setUseFast] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      let response;
      if (useThinking) {
        response = await chatWithThinking(input);
      } else if (useFast) {
        response = await chatFast(input);
      } else {
        response = await chatWithThinking(input); // Default to pro
      }

      setMessages(prev => [...prev, { role: 'model', text: response.text || 'No response.' }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: 'Error: Failed to fetch response.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const base64 = await fileToBase64(file);
      const response = await transcribeAudio(base64);
      setInput(response.text || '');
    } catch (err) {
      alert('Failed to transcribe audio.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">Chat Hub</h2>
          <p className="text-gray-500">Intelligent conversations with Thinking & Flash Lite modes.</p>
        </div>
        <div className="flex gap-2">
           <button 
            onClick={() => { setUseThinking(true); setUseFast(false); }}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${useThinking ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-600'}`}
          >
            Thinking Mode
          </button>
          <button 
            onClick={() => { setUseThinking(false); setUseFast(true); }}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${useFast ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-600'}`}
          >
            Fast Mode
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto space-y-4 p-4 bg-white rounded-2xl shadow-sm border border-gray-100 min-h-[400px]">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-gray-400">
            <i className="fa-solid fa-comments text-4xl mb-4"></i>
            <p>Start a conversation to see Gemini's intelligence in action.</p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-4 py-3 rounded-2xl ${
              m.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-800'
            }`}>
              <p className="whitespace-pre-wrap">{m.text}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 px-4 py-3 rounded-2xl animate-pulse flex items-center gap-2 text-gray-500">
              <i className="fa-solid fa-circle-notch fa-spin"></i>
              Gemini is processing...
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="flex gap-2 bg-white p-2 rounded-2xl shadow-lg border border-gray-100 sticky bottom-4">
        <input 
          type="file" 
          accept="audio/*" 
          className="hidden" 
          ref={fileInputRef} 
          onChange={handleAudioUpload}
        />
        <button 
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-3 text-gray-400 hover:text-indigo-600 transition-colors"
          title="Transcribe Audio"
        >
          <i className="fa-solid fa-microphone"></i>
        </button>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message here..."
          className="flex-1 bg-transparent border-none outline-none px-2"
        />
        <button 
          disabled={isLoading}
          className="bg-indigo-600 text-white w-10 h-10 rounded-xl flex items-center justify-center hover:bg-indigo-700 transition-all disabled:opacity-50"
        >
          <i className="fa-solid fa-paper-plane"></i>
        </button>
      </form>
    </div>
  );
};

export default ChatStudio;
