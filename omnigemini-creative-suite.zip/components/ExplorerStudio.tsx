
import React, { useState } from 'react';
import { searchGrounding, mapsGrounding } from '../geminiService';

const ExplorerStudio: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<{text: string; chunks: any[]} | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'search' | 'maps'>('search');

  const handleExplore = async () => {
    if (!query.trim() || isLoading) return;
    setIsLoading(true);
    setResult(null);

    try {
      let response;
      if (mode === 'search') {
        response = await searchGrounding(query);
      } else {
        const coords = await new Promise<{lat: number; lng: number} | null>((resolve) => {
          navigator.geolocation.getCurrentPosition(
            (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
            () => resolve(null)
          );
        });
        response = await mapsGrounding(query, coords?.lat, coords?.lng);
      }

      setResult({
        text: response.text || 'No description provided.',
        chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
      });
    } catch (err) {
      alert('Exploration failed.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-2xl font-bold">Explorer</h2>
        <p className="text-gray-500">Real-time information grounded with Google Search and Maps.</p>
      </header>

      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex gap-2 p-1 bg-gray-200 rounded-xl w-fit mx-auto">
          <button 
            onClick={() => setMode('search')}
            className={`px-6 py-2 rounded-lg font-bold transition-all ${mode === 'search' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <i className="fa-brands fa-google mr-2"></i> Search
          </button>
          <button 
            onClick={() => setMode('maps')}
            className={`px-6 py-2 rounded-lg font-bold transition-all ${mode === 'maps' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <i className="fa-solid fa-location-dot mr-2"></i> Maps
          </button>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex gap-4">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={mode === 'search' ? "Search for latest news, events, or facts..." : "Find nearby restaurants, landmarks, or reviews..."}
            className="flex-1 border-none outline-none p-2 text-lg"
          />
          <button
            onClick={handleExplore}
            disabled={isLoading}
            className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2"
          >
            {isLoading ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-bolt"></i>}
            Explore
          </button>
        </div>

        {result && (
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="prose max-w-none text-gray-800 text-lg leading-relaxed whitespace-pre-wrap">
              {result.text}
            </div>
            
            <div className="pt-6 border-t border-gray-100">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Sources & Citations</h4>
              <div className="flex flex-wrap gap-2">
                {result.chunks.map((chunk, i) => {
                  const data = chunk.web || chunk.maps;
                  if (!data) return null;
                  return (
                    <a 
                      key={i} 
                      href={data.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-lg text-sm font-medium hover:bg-indigo-100 transition-colors"
                    >
                      <i className={`fa-solid ${chunk.web ? 'fa-globe' : 'fa-location-dot'} text-xs`}></i>
                      {data.title || 'Source'}
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {!result && !isLoading && (
          <div className="py-20 text-center text-gray-300">
             <i className={`fa-solid ${mode === 'search' ? 'fa-magnifying-glass' : 'fa-map-location-dot'} text-6xl mb-4`}></i>
             <p className="text-lg">Ask anything to get grounded, up-to-date information.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExplorerStudio;
