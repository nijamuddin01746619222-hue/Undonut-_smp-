
import React, { useState, useRef } from 'react';
import { generateImage, editImage, analyzeMedia } from '../geminiService';
import { fileToBase64 } from '../utils';

const ImageStudio: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editInputRef = useRef<HTMLInputElement>(null);

  const handleGenerate = async () => {
    if (!prompt || isLoading) return;
    setIsLoading(true);
    setAnalysis(null);
    try {
      const response = await generateImage(prompt, aspectRatio, imageSize);
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setGeneratedImageUrl(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (err) {
      alert('Generation failed. Ensure you have the right permissions.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !prompt) {
      alert('Please provide a prompt first to edit the image.');
      return;
    }
    setIsLoading(true);
    try {
      const base64 = await fileToBase64(file);
      const response = await editImage(base64, prompt);
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setGeneratedImageUrl(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (err) {
      alert('Edit failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnalyze = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);
    try {
      const base64 = await fileToBase64(file);
      const response = await analyzeMedia(base64, "Analyze this image in detail.", "image/png");
      setAnalysis(response.text || 'No analysis provided.');
    } catch (err) {
      alert('Analysis failed.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-2xl font-bold">Visual Studio</h2>
        <p className="text-gray-500">Create, edit, and analyze images with Gemini 3 Pro & 2.5 Flash.</p>
      </header>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <label className="block text-sm font-semibold mb-2">Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. A futuristic city in cyberpunk style..."
              className="w-full h-32 p-3 bg-gray-50 rounded-xl border-none outline-none focus:ring-2 focus:ring-indigo-500"
            />
            
            <div className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Aspect Ratio</label>
                <select 
                  value={aspectRatio} 
                  onChange={(e) => setAspectRatio(e.target.value)}
                  className="w-full p-2 bg-gray-50 rounded-lg text-sm"
                >
                  <option>1:1</option>
                  <option>3:4</option>
                  <option>4:3</option>
                  <option>9:16</option>
                  <option>16:9</option>
                  <option>21:9</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Resolution</label>
                <div className="flex gap-2">
                  {(['1K', '2K', '4K'] as const).map(size => (
                    <button
                      key={size}
                      onClick={() => setImageSize(size)}
                      className={`flex-1 py-1 px-2 rounded-md text-xs font-bold ${imageSize === size ? 'bg-indigo-600 text-white' : 'bg-gray-100'}`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full mt-6 bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all"
            >
              {isLoading ? <i className="fa-solid fa-spinner fa-spin mr-2"></i> : null}
              Generate New
            </button>
            
            <div className="grid grid-cols-2 gap-2 mt-2">
               <button 
                onClick={() => editInputRef.current?.click()}
                className="py-2 px-3 border border-indigo-200 text-indigo-600 text-sm rounded-xl font-medium hover:bg-indigo-50 transition-all text-center"
              >
                Edit Image
              </button>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="py-2 px-3 border border-indigo-200 text-indigo-600 text-sm rounded-xl font-medium hover:bg-indigo-50 transition-all text-center"
              >
                Analyze Image
              </button>
            </div>
            <input type="file" ref={editInputRef} onChange={handleEdit} className="hidden" accept="image/*" />
            <input type="file" ref={fileInputRef} onChange={handleAnalyze} className="hidden" accept="image/*" />
          </div>
        </div>

        <div className="md:col-span-2">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 h-full min-h-[500px] flex items-center justify-center relative overflow-hidden">
            {isLoading && !generatedImageUrl && (
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                <p className="text-gray-500">Creating your masterpiece...</p>
              </div>
            )}
            {!isLoading && !generatedImageUrl && !analysis && (
              <div className="text-center text-gray-400">
                <i className="fa-regular fa-image text-6xl mb-4"></i>
                <p>Your creation will appear here.</p>
              </div>
            )}
            {generatedImageUrl && (
              <img src={generatedImageUrl} alt="Generated" className="max-w-full max-h-full rounded-xl object-contain" />
            )}
            {analysis && (
              <div className="w-full h-full p-8 overflow-y-auto">
                <h3 className="font-bold text-lg mb-4">Analysis Results</h3>
                <div className="prose prose-indigo max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">
                  {analysis}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageStudio;
