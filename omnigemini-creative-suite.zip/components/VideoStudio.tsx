
import React, { useState, useRef } from 'react';
import { generateVideo, analyzeMedia } from '../geminiService';
import { fileToBase64 } from '../utils';

const VideoStudio: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [resolution, setResolution] = useState<'720p' | '1080p'>('1080p');
  
  const imgToVidRef = useRef<HTMLInputElement>(null);
  const analyzeRef = useRef<HTMLInputElement>(null);

  const handleGenerateTextToVideo = async () => {
    if (!prompt || isLoading) return;
    setIsLoading(true);
    setAnalysis(null);
    setVideoUrl(null);
    try {
      const uri = await generateVideo(prompt, aspectRatio, resolution);
      if (uri) setVideoUrl(`${uri}&key=${process.env.API_KEY}`);
    } catch (err) {
      alert('Video generation failed. Check API key and billing.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageToVideo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);
    setVideoUrl(null);
    try {
      const base64 = await fileToBase64(file);
      const uri = await generateVideo(prompt || "Animate this photo", aspectRatio, resolution, base64);
      if (uri) setVideoUrl(`${uri}&key=${process.env.API_KEY}`);
    } catch (err) {
      alert('Animate failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnalyzeVideo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);
    try {
      const base64 = await fileToBase64(file);
      const response = await analyzeMedia(base64, "Provide a summary of the key information in this video.", "video/mp4");
      setAnalysis(response.text || 'No data returned.');
    } catch (err) {
      alert('Analysis failed.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-2xl font-bold">Motion Studio</h2>
        <p className="text-gray-500">Bring ideas to life with Veo 3.1 & Analyze scenes with Gemini Pro.</p>
      </header>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <label className="block text-sm font-semibold mb-2">Description</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. A neon hologram of a cat driving at top speed..."
              className="w-full h-32 p-3 bg-gray-50 rounded-xl border-none outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
            />
            
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 mb-1">Ratio</label>
                <select 
                  value={aspectRatio} 
                  onChange={(e) => setAspectRatio(e.target.value as any)}
                  className="w-full p-2 bg-gray-50 rounded-lg text-sm"
                >
                  <option value="16:9">16:9 (Landscape)</option>
                  <option value="9:16">9:16 (Portrait)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 mb-1">Res</label>
                <select 
                  value={resolution} 
                  onChange={(e) => setResolution(e.target.value as any)}
                  className="w-full p-2 bg-gray-50 rounded-lg text-sm"
                >
                  <option value="1080p">1080p</option>
                  <option value="720p">720p</option>
                </select>
              </div>
            </div>

            <div className="mt-6 space-y-3">
              <button
                onClick={handleGenerateTextToVideo}
                disabled={isLoading}
                className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50"
              >
                {isLoading ? <i className="fa-solid fa-spinner fa-spin mr-2"></i> : null}
                Generate Video
              </button>
              
              <div className="flex gap-2">
                <button 
                  onClick={() => imgToVidRef.current?.click()}
                  className="flex-1 py-2 px-3 bg-white border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 text-xs"
                >
                  <i className="fa-solid fa-image-polaroid mr-1"></i> Animate Photo
                </button>
                <button 
                  onClick={() => analyzeRef.current?.click()}
                  className="flex-1 py-2 px-3 bg-white border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 text-xs"
                >
                  <i className="fa-solid fa-magnifying-glass mr-1"></i> Analyze Video
                </button>
              </div>
            </div>

            <input type="file" ref={imgToVidRef} onChange={handleImageToVideo} className="hidden" accept="image/*" />
            <input type="file" ref={analyzeRef} onChange={handleAnalyzeVideo} className="hidden" accept="video/mp4" />
          </div>

          <div className="bg-blue-50 p-4 rounded-xl text-blue-800 text-xs flex gap-3">
            <i className="fa-solid fa-info-circle mt-1"></i>
            <p>Note: Video generation may take a few minutes. We'll poll the progress for you.</p>
          </div>
        </div>

        <div className="md:col-span-2">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 h-full min-h-[500px] flex items-center justify-center">
            {isLoading && (
              <div className="text-center">
                <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-indigo-600 font-bold">Dreaming up your pixels...</p>
                <p className="text-gray-400 text-sm mt-2 italic">Fetching textures, calculating physics, lighting scenes...</p>
              </div>
            )}
            {!isLoading && !videoUrl && !analysis && (
              <div className="text-center text-gray-300">
                <i className="fa-solid fa-clapperboard text-6xl mb-4"></i>
                <p>Ready for action.</p>
              </div>
            )}
            {videoUrl && (
              <video src={videoUrl} controls autoPlay loop className="max-w-full max-h-[600px] rounded-xl shadow-lg" />
            )}
            {analysis && (
              <div className="w-full h-full p-8 overflow-y-auto">
                <h3 className="font-bold text-lg mb-4">Video Summary</h3>
                <div className="text-gray-700 whitespace-pre-wrap">{analysis}</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoStudio;
