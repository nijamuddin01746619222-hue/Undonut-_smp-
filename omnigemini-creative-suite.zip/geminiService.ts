
import { GoogleGenAI, Type, Modality } from "@google/genai";

// Ensure process.env.API_KEY is available
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const chatWithThinking = async (prompt: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      thinkingConfig: { thinkingBudget: 32768 }
    },
  });
};

export const chatFast = async (prompt: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: 'gemini-2.5-flash-lite-latest',
    contents: prompt,
  });
};

export const transcribeAudio = async (base64Audio: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Audio, mimeType: 'audio/wav' } },
        { text: 'Transcribe this audio accurately.' }
      ]
    },
  });
};

export const generateImage = async (prompt: string, aspectRatio: string, imageSize: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: prompt }] },
    config: {
      imageConfig: {
        aspectRatio: aspectRatio as any,
        imageSize: imageSize as any
      }
    }
  });
};

export const editImage = async (base64Image: string, prompt: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType: 'image/png' } },
        { text: prompt }
      ]
    }
  });
};

export const analyzeMedia = async (base64Data: string, prompt: string, mimeType: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Data, mimeType } },
        { text: prompt }
      ]
    }
  });
};

export const generateVideo = async (prompt: string, aspectRatio: '16:9' | '9:16', resolution: '720p' | '1080p', imageBytes?: string) => {
  const ai = getAI();
  const config: any = {
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    config: {
      numberOfVideos: 1,
      resolution,
      aspectRatio
    }
  };
  
  if (imageBytes) {
    config.image = { imageBytes, mimeType: 'image/png' };
  }

  let operation = await ai.models.generateVideos(config);
  
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }
  
  return operation.response?.generatedVideos?.[0]?.video?.uri;
};

export const generateSpeech = async (text: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });
};

export const searchGrounding = async (query: string) => {
  const ai = getAI();
  return await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: query,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });
};

export const mapsGrounding = async (query: string, lat?: number, lng?: number) => {
  const ai = getAI();
  const config: any = {
    tools: [{ googleMaps: {} }],
  };
  
  if (lat && lng) {
    config.toolConfig = {
      retrievalConfig: {
        latLng: { latitude: lat, longitude: lng }
      }
    };
  }

  return await ai.models.generateContent({
    model: "gemini-2.5-flash-latest",
    contents: query,
    config,
  });
};
