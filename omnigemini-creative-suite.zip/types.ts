
export enum StudioType {
  CHAT = 'CHAT',
  VISUAL = 'VISUAL',
  MOTION = 'MOTION',
  VOCAL = 'VOCAL',
  EXPLORER = 'EXPLORER'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isThinking?: boolean;
  groundingUrls?: { title: string; uri: string }[];
}

export interface ImageSettings {
  aspectRatio: string;
  imageSize: '1K' | '2K' | '4K';
}

export interface VideoSettings {
  aspectRatio: '16:9' | '9:16';
  resolution: '720p' | '1080p';
}
